module.exports = {
  bot: {
    token: "ODYwMDM2NTU2OTgyNDUyMjM0.YN1ZdQ.0Aj11YgvmAbyJS-tU8ntUU-8BfI",
    prefix: "-",
    owners: ["745581095747059722,757992794189987961"],
    mongourl: "mongodb://newuser:newuser@cluster0-shard-00-00.uf6th.mongodb.net:27017,cluster0-shard-00-01.uf6th.mongodb.net:27017,cluster0-shard-00-02.uf6th.mongodb.net:27017/myFirstDatabase?ssl=true&replicaSet=atlas-6cm745-shard-0&authSource=admin&retryWrites=true&w=majority"
  },

  website: {
    callback: "https://DiscordTopgg.evilsourav.repl.co/callback",
    secret: "T_tUlU3CM4ZSkcRDhv1tVSpfZZjD1j9C",
    clientID: "858312253572907009",
    tags: ["Moderation", "Fun", "Minecraft", "Economy", "Guard", "NSFW", "Anime", "Invite", "Music", "Logging", "Web Dashboard", "Reddit", "Youtube", "Twitch", "Crypto", "Leveling", "Game", "Roleplay", "Utility"]
  },

  server: {
    id: "862923330809364530",
    roles: {
      yonetici: "858300936052539402",
      moderator: "858300998073843712",
      profile: {
        booster: "858301058593325096",
        sponsor: "858301125311463454",
        supporter: "858301170279907348",
        partnerRole: "858301250436202497"
      },
      codeshare: {
        javascript: "JS",
        html: "HTML",
        altyapilar: "substructure",
        bdfd: "BDFD",
        besdavet: "5 INVITES",
        ondavet: "10 INVITES",
        onbesdavet: "15 INVITES",
        yirmidavet: "20 INVITES"
      },
      botlist: {
        developer: "745581095747059722",
        certified_developer: "757992794189987961",
        bot: "858294946234761236",
        certified_bot: "858294946234761236"
      }
    },
    channels: {
      codelog: "862923330809364533",
      login: "862923330809364533",
      webstatus: "858296046869807106",
      uptimelog: "858296100468031518",
      botlog: "862923330809364533",
      votes: "858296224947896370"
    }
  }


}